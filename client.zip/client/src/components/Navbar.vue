<template>
<nav class="navbar navbar-icon-top navbar-expand-lg navbar-dark navbar-full" style="background-color: #ffffff">
  <div class="container">
    <a class="navbar-brand" href="#"><img src="../assets/ign.png" style="height: 100px;"></a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>

    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav ml-auto mr-auto">
        <li class="nav-item active">
          <a class="nav-link">
          <router-link style="color:black" to="/">
          Home
          </router-link>
          </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link">
          <router-link style="color:black" to="/Members">
          Members
          </router-link>
            </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link">
          <router-link style="color:black" to="/News">
          News
          </router-link>
            </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link">
            <router-link style="color:black" to="/Signup">
            Signup
            </router-link>
             </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link">
            <router-link style="color:black" to="/Login">
            Login
            </router-link>
              </a>
        </li>
        <li class="nav-item active">
          <a class="nav-link">
            <router-link style="color:black" to="/Events">
            Events
            </router-link>
              </a>
        </li>
      </ul>
      <form class="form-inline my-2 my-lg-0">
        <input class="form-control mr-sm-2" type="text" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-danger my-2 my-sm-0" type="submit">Search</button>
      </form>
    </div>
  </div>
</nav>
</template>
