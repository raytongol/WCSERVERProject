<template>
    <div class="container h-100">
        <div class ="row h-100 justify-content-center align-items-center background-form">
            <div class="col-md-5">
                <h2>Log-in</h2>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Username" v-model="username"/>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" v-model="password"/>
                </div>
                <div class="form-group">
                <button class ="btn btn-lg btn-secondary mr-4" type="submit">Log-in</button>
                <button class ="btn btn-lg btn-secondary mr-4" type="reset">Cancel</button>
                </div>
            </div>
        </div>
    </div>
</template>

<script>

</script>
