<template>
<div>
  <header>
    <img class="img-fluid d-block mx-auto mt-3 mb-5" src="../assets/banner.jpg">
  </header>

  <div class="container text-center" style="background-color: #bf2025;">
    <h1>LATEST NEWS!</h1>
  </div>

  <!-- Content section -->
  <section class="py-3">
    <div class="container">
      <h3>The Walking Dead Boss Says Michonne's 'Story Isn't Done'</h3>
      <p class="lead">Star Danai Gurira and TWD boss Scott Gimple talk about Michonne's next steps.</p>
      <p>With tonight's Walking Dead episode "What We Become" marking star Danai Gurira's final appearance on the series as Michonne (as she and the character head off into the Rick Grimes movie trilogy), both Gurira 
        and Walking Dead Chief Content Officer Scott M. Gimple appeared on AMC's Talking Dead after show to discuss the episode and Michonne's surreal "Sliding Doors"-style exit.</p>
    </div>
  </section>

  <!-- Content section -->
  <section class="py-4">
    <div class="container">
      <h3>How Adventure Time Inspired the Creation of Filipino RPG, Grand Guilds</h3>
      <p class="lead">Who knew watching cartoons can be so inspirational?</p>
      <p>LWe talked to the director of Grand Guilds, Justin Villegas, on what inspired the blend of tactical RPGs and card-based on combat, and what goes behind making such a unique game for the Nintendo Switch and Steam.</p>
    </div>
  </section>


  <!-- Content section -->
  <section class="py-4">
    <div class="container">
      <h3>Top 5 iOS Games to Play When You’re Avoiding Covid-19</h3>
      <p class="lead">A mobile game a day keeps the virus at bay.</p>
      <p>If you’re stuck at home, you’re going to have to diversify your games beyond PC, PS4, and the Nintendo Switch. Here are our picks for the top five games to play on your Apple device. Spoiler alert: No Apple Arcade games, just games you can find on your regular App Store.</p>
    </div>
  </section>
</div>

</template>

<script>
export default {
  name: 'home',

}
</script>