<template>
<div class="container">
    <header>
        <img class="img-fluid d-block mx-auto mt-3 mb-5" src="../assets/ignenter.png">
    </header>
    <!--Start code-->
    <div class="col-12 pb-5">
        <div class="row">
            <section class="row">
                <div class="col-12 col-md-6 pt-2 pl-md-1 mb-3 mb-lg-4">
                    <div id="featured" class="carousel slide carousel" data-ride="carousel">
                        <div class="carousel-inner">
                            <div class="card border-0 rounded-0 text-light overflow zoom">
                                    <div class="position-relative">
                                        <div class="ratio_left-cover-1 image-wrapper">
                                            <a>
                                                <img class="img-fluid"
                                                     src="../assets/press conference.png"
                                                     alt="Bootstrap news template" style="height: 300px">
                                            </a>
                                        </div>
                                        <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                            <a>
                                                <h2 class="h3 post-title text-white my-1">Microsoft Xbox Press Conference Recap</h2>
                                            </a>
                                            <div class="news-meta">
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                
                <div class="col-12 col-md-6 pt-2 pl-md-1 mb-3 mb-lg-4">
                    <div class="row">
                        <div class="col-6 pb-1 pt-0 pr-1">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                src="../assets/ubisoft.png"
                                                style="height: 230px">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">Ubisoft Press Conference Recap</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-6 pb-1 pl-1 pt-0">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                 src="../assets/square.png"
                                                style="height: 230px;">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">Square Enix Press Conference Recap</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                        <div class="col-6 pb-1 pr-1 pt-1">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                src="../assets/nintendo.png"
                                                style="height: 230px;">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">Nintendo E3 Direct Recap</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-6 pb-1 pr-1 pt-1">
                            <div class="card border-0 rounded-0 text-white overflow zoom">
                                <div class="position-relative">
                                    <div class="ratio_right-cover-2 image-wrapper">
                                        <a>
                                            <img class="img-fluid"
                                                src="../assets/canceled.png"
                                                style="height: 230px;">
                                        </a>
                                    </div>
                                    <div class="position-absolute p-2 p-lg-3 b-0 w-100 bg-shadow">
                                        <a>
                                            <h2 class="h6 text-white my-1">E3 Cancelled Due To Coronavirus Concerns - IGN Daily Fix</h2>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
        </div>
    </div>
    
    <div class="row mb-4">
        <div class="col-12 text-center">
            <p>Design by Ari Budin <a target="_blank" href="https://bootstrap.news/bootstrap-4-template-news-portal-magazine/">Bootstrap.News</a> | images by pixabay and pexels</p>
        </div>
    </div>
</div>
</template>

<style>


.b-0 {
    bottom: 0;
}
.bg-shadow {
    background: rgba(76, 76, 76, 0);
    background: -webkit-gradient(left top, left bottom, color-stop(0%, rgba(179, 171, 171, 0)), color-stop(49%, rgba(48, 48, 48, 0.37)), color-stop(100%, rgba(19, 19, 19, 0.8)));
    background: linear-gradient(to bottom, rgba(179, 171, 171, 0) 0%, rgba(48, 48, 48, 0.71) 49%, rgba(19, 19, 19, 0.8) 100%);
    filter: progid:DXImageTransform.Microsoft.gradient( startColorstr='#4c4c4c', endColorstr='#131313', GradientType=0 );
}
.top-indicator {
    right: 0;
    top: 1rem;
    bottom: inherit;
    left: inherit;
    margin-right: 1rem;
}
.overflow {
    position: relative;
    overflow: hidden;
}
.zoom img {
    transition: all 0.2s linear;
}
.zoom:hover img {
    -webkit-transform: scale(1.1);
    transform: scale(1.1);
}
</style>