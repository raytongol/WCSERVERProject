<template>
    <div class="container h-100">
        <div class="bg-dark row justify-content-center">
            <h1>REGISTRATION FORM</h1>
        </div>
        <div class ="row h-100 justify-content-center align-items-center background-form" style="display:flex;"> 
               
            <div class="col-md-6 mx-auto">
                <div class="form-group">
                    <label for="first_name ">First Name</label>
                    <input type="text" class="form-control" name="fname" id="fname" placeholder="First Name" v-model="fname"/>
                </div>
                <div class="form-group">
                    <label for="middle_initial">Middle Initial</label>
                    <input type="text" class="form-control" name="midinitial" id="midinitial" placeholder="Middle Initial" v-model="midinitial"/>
                </div>
                <div class="form-group">
                    <label for="last_name">Last Name</label>
                    <input type="text" class="form-control" name="lname" id="lname" placeholder="Last Name" v-model="lname"/>
                </div>
                <div class="form-group">
                    <label for="address">Address</label>
                    <textarea type="text" class="form-control" name="address" id="midinitial" placeholder="Address" v-model="address"/>
                </div>
                <div class="form-group">
                    <label for="birthdate">Birthdate</label>
                    <input type="text" class="form-control" name="birthdate" id="birthdate" placeholder="Birthdate" v-model="birthdate"/>
                </div>
                <div class="form-group">
                    <label for="sex">Sex</label>
                    <input type="text" class="form-control" name="sex" id="sex" placeholder="Sex" v-model="sex"/>
                </div>
                <div class="form-group">
                    <label for="email">E-mail Address</label>
                    <input type="email" class="form-control" name="email" id="email" placeholder="E-mail Address" v-model="email" required autocomplete="off"/>
                </div>
                <div class="form-group">
                    <label for="username">Username</label>
                    <input type="text" class="form-control" name="username" id="username" placeholder="Username" v-model="username"/>
                </div>
                <div class="form-group">
                    <label for="password">Password</label>
                    <input type="password" class="form-control" name="password" id="password" placeholder="Password" v-model="password"/>
                </div>
                 <div class="form-group">
                    <label for="cpassword">Confirm Password</label>
                    <input type="password" class="form-control" name="cpassword" id="cpassword" placeholder="Confirm Password" v-model="cpassword"/>
                </div>
                <div class="form-group">
                <button class ="btn btn-lg btn-secondary mr-4 bg-dark" type="submit">Register</button>
                <button class ="btn btn-lg btn-secondary bg-dark" type="submit">Cancel</button>
                </div>

            </div>
        </div>
    </div>
</template>

<script>

</script>
